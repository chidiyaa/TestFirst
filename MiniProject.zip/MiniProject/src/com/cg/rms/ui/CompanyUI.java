package com.cg.rms.ui;

public interface CompanyUI {
	public void regCompDetails(String id);
	public void postJobReq(String id) ;
	public void searchCandidate();
	  public void showCompanyMenu(String id);
}
